package com.example.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.gamebooster.utils.DeviceUtils

class MainActivity : AppCompatActivity() {
    private lateinit var boostButton: Button
    private lateinit var statusText: TextView
    private lateinit var deviceStats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        boostButton = findViewById(R.id.boostButton)
        statusText = findViewById(R.id.statusText)
        deviceStats = findViewById(R.id.deviceStats)

        updateStats()

        boostButton.setOnClickListener {
            freeUpMemory()
            updateStats()
        }
    }

    private fun freeUpMemory() {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningProcesses = activityManager.runningAppProcesses

        for (process in runningProcesses) {
            if (process.importance > ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                android.os.Process.killProcess(process.pid)
            }
        }

        statusText.text = "Memory Boosted!"
    }

    private fun updateStats() {
        val stats = DeviceUtils.getSystemStats(this)
        deviceStats.text = stats
    }
}
