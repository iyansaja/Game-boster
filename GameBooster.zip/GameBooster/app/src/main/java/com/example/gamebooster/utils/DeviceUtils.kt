package com.example.gamebooster.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build

object DeviceUtils {
    fun getSystemStats(context: Context): String {
        val memoryInfo = ActivityManager.MemoryInfo()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(memoryInfo)

        val availMem = memoryInfo.availMem / 1048576L
        val totalMem = memoryInfo.totalMem / 1048576L

        return "RAM: $availMem MB / $totalMem MB\nCPU: Simulated Boost\nGPU: Simulated Boost"
    }
}
