import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const performanceMetrics = pgTable("performance_metrics", {
  id: serial("id").primaryKey(),
  cpuUsage: real("cpu_usage").notNull(),
  ramUsage: real("ram_usage").notNull(),
  ramTotal: real("ram_total").notNull(),
  fps: integer("fps").notNull(),
  gpuTemp: real("gpu_temp").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  processName: text("process_name").notNull(),
  isActive: boolean("is_active").default(false).notNull(),
  currentFps: integer("current_fps"),
  status: text("status").notNull(), // "running", "background", "idle"
  iconUrl: text("icon_url"),
});

export const gamingProfiles = pgTable("gaming_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  isActive: boolean("is_active").default(false).notNull(),
  cpuPriority: text("cpu_priority").notNull(), // "high", "normal", "low"
  ramOptimization: boolean("ram_optimization").default(true).notNull(),
  backgroundAppsDisabled: boolean("background_apps_disabled").default(false).notNull(),
});

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  gamingModeEnabled: boolean("gaming_mode_enabled").default(false).notNull(),
  lastOptimized: timestamp("last_optimized"),
  autoOptimization: boolean("auto_optimization").default(false).notNull(),
});

export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // "performance", "cleanup", "update"
  priority: text("priority").notNull(), // "high", "medium", "low"
  isCompleted: boolean("is_completed").default(false).notNull(),
});

export const insertPerformanceMetricsSchema = createInsertSchema(performanceMetrics).omit({
  id: true,
  timestamp: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
});

export const insertGamingProfileSchema = createInsertSchema(gamingProfiles).omit({
  id: true,
});

export const insertSystemSettingsSchema = createInsertSchema(systemSettings).omit({
  id: true,
});

export const insertRecommendationSchema = createInsertSchema(recommendations).omit({
  id: true,
});

export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = z.infer<typeof insertPerformanceMetricsSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type GamingProfile = typeof gamingProfiles.$inferSelect;
export type InsertGamingProfile = z.infer<typeof insertGamingProfileSchema>;

export type SystemSettings = typeof systemSettings.$inferSelect;
export type InsertSystemSettings = z.infer<typeof insertSystemSettingsSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
