/**
 * BoostButton.js - Cross-Platform Game Booster Button
 * Compatible with Android & iOS React Native
 */
import React, { useState, useEffect } from 'react';
import {
  TouchableOpacity,
  Text,
  View,
  StyleSheet,
  Animated,
  Vibration,
  Platform,
  Dimensions,
} from 'react-native';

const { width } = Dimensions.get('window');

const BoostButton = ({ onBoost, isLoading = false, systemInfo }) => {
  const [scaleAnim] = useState(new Animated.Value(1));
  const [glowAnim] = useState(new Animated.Value(0));
  const [rotateAnim] = useState(new Animated.Value(0));

  useEffect(() => {
    if (isLoading) {
      // Spinning animation for loading state
      Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ).start();
    } else {
      rotateAnim.setValue(0);
    }
  }, [isLoading]);

  const handlePress = () => {
    // Cross-platform haptic feedback
    if (Platform.OS === 'ios') {
      // iOS haptic feedback
      const { HapticFeedback } = require('react-native');
      HapticFeedback?.impact?.(HapticFeedback.ImpactFeedbackStyle.Medium);
    } else {
      // Android vibration
      Vibration.vibrate(50);
    }

    // Button press animation
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();

    // Glow effect animation
    Animated.timing(glowAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: false,
    }).start(() => {
      Animated.timing(glowAnim, {
        toValue: 0,
        duration: 700,
        useNativeDriver: false,
      }).start();
    });

    if (onBoost && !isLoading) {
      onBoost();
    }
  };

  const getBoostStatus = () => {
    if (isLoading) return 'MENGOPTIMASI...';
    if (systemInfo?.ramUsage > 80) return 'OPTIMASI DARURAT';
    if (systemInfo?.cpuTemp > 75) return 'COOLING MODE';
    return 'OPTIMASI SEKARANG';
  };

  const getButtonColor = () => {
    if (isLoading) return '#FFA500';
    if (systemInfo?.ramUsage > 80) return '#FF4444';
    if (systemInfo?.cpuTemp > 75) return '#00BFFF';
    return '#4A90FB';
  };

  const spin = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <View style={styles.container}>
      {/* Main Boost Button */}
      <Animated.View
        style={[
          styles.glowContainer,
          {
            shadowOpacity: glowAnim.interpolate({
              inputRange: [0, 1],
              outputRange: [0.3, 0.8],
            }),
            shadowColor: getButtonColor(),
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <TouchableOpacity
          onPress={handlePress}
          disabled={isLoading}
          style={[styles.buttonContainer, { backgroundColor: getButtonColor() }]}
          activeOpacity={0.8}
        >
          <View style={styles.innerCircle}>
            <Animated.View
              style={[
                styles.iconContainer,
                isLoading && { transform: [{ rotate: spin }] },
              ]}
            >
              <Text style={styles.iconText}>⚡</Text>
            </Animated.View>
            <Text style={styles.buttonText}>{getBoostStatus()}</Text>
          </View>
        </TouchableOpacity>
      </Animated.View>

      {/* Performance Indicators */}
      <View style={styles.indicators}>
        <View style={[styles.indicator, styles.ramIndicator]}>
          <Text style={styles.indicatorLabel}>RAM</Text>
          <Text style={styles.indicatorValue}>
            {systemInfo?.ramUsage || 3.8} GB
          </Text>
        </View>
        <View style={[styles.indicator, styles.tempIndicator]}>
          <Text style={styles.indicatorLabel}>Suhu</Text>
          <Text style={styles.indicatorValue}>
            {systemInfo?.cpuTemp || 44}°C
          </Text>
        </View>
        <View style={[styles.indicator, styles.statusIndicator]}>
          <Text style={styles.indicatorLabel}>Status</Text>
          <Text style={styles.indicatorValue}>
            {systemInfo?.batteryStatus || 'baterai'}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    backgroundColor: '#141820',
  },
  glowContainer: {
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 25,
    elevation: Platform.OS === 'android' ? 15 : 0,
  },
  buttonContainer: {
    width: 200,
    height: 200,
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  innerCircle: {
    width: '85%',
    height: '85%',
    borderRadius: 85,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  iconContainer: {
    marginBottom: 8,
  },
  iconText: {
    fontSize: 50,
    color: '#FFFFFF',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  indicators: {
    flexDirection: 'row',
    marginTop: 40,
    justifyContent: 'space-around',
    width: width * 0.9,
    paddingHorizontal: 20,
  },
  indicator: {
    alignItems: 'center',
    backgroundColor: '#1B2028',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2D333A',
    minWidth: 80,
  },
  ramIndicator: {
    borderColor: '#4A90FB',
  },
  tempIndicator: {
    borderColor: '#4A90FB',
  },
  statusIndicator: {
    borderColor: '#4A90FB',
  },
  indicatorLabel: {
    color: '#8B949E',
    fontSize: 12,
    marginBottom: 6,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  indicatorValue: {
    color: '#F0F6FC',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
});

export default BoostButton;