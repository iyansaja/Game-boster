/**
 * SystemInfo.js - Cross-Platform System Information Component
 * Compatible with Android & iOS React Native
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Platform,
  Dimensions,
  ScrollView,
} from 'react-native';
import DeviceInfo from 'react-native-device-info';

const { width } = Dimensions.get('window');

const SystemInfo = ({ onSystemUpdate }) => {
  const [systemData, setSystemData] = useState({
    deviceName: '',
    systemVersion: '',
    ramUsage: 0,
    ramTotal: 0,
    batteryLevel: 0,
    cpuTemp: 0,
    storageUsed: 0,
    storageTotal: 0,
    networkType: '',
    isCharging: false,
  });

  useEffect(() => {
    loadSystemInfo();
    
    // Update system info every 2 seconds
    const interval = setInterval(loadSystemInfo, 2000);
    
    return () => clearInterval(interval);
  }, []);

  const loadSystemInfo = async () => {
    try {
      const deviceName = await DeviceInfo.getDeviceName();
      const systemVersion = DeviceInfo.getSystemVersion();
      const batteryLevel = await DeviceInfo.getBatteryLevel();
      const totalMemory = await DeviceInfo.getTotalMemory();
      const usedMemory = await DeviceInfo.getUsedMemory();
      const totalDiskCapacity = await DeviceInfo.getTotalDiskCapacity();
      const freeDiskStorage = await DeviceInfo.getFreeDiskStorage();
      
      // Calculate system metrics
      const ramUsagePercent = Math.round((usedMemory / totalMemory) * 100);
      const ramUsageGB = (usedMemory / (1024 * 1024 * 1024)).toFixed(1);
      const ramTotalGB = (totalMemory / (1024 * 1024 * 1024)).toFixed(1);
      const storageUsedGB = ((totalDiskCapacity - freeDiskStorage) / (1024 * 1024 * 1024)).toFixed(1);
      const storageTotalGB = (totalDiskCapacity / (1024 * 1024 * 1024)).toFixed(1);
      
      // Simulate CPU temperature (real implementation would need native modules)
      const cpuTemp = Math.floor(Math.random() * 15) + 40; // 40-55°C
      
      const newSystemData = {
        deviceName,
        systemVersion,
        ramUsage: ramUsagePercent,
        ramUsageGB: parseFloat(ramUsageGB),
        ramTotal: parseFloat(ramTotalGB),
        batteryLevel: Math.round(batteryLevel * 100),
        cpuTemp,
        storageUsed: parseFloat(storageUsedGB),
        storageTotal: parseFloat(storageTotalGB),
        networkType: 'WiFi', // Would need network info library
        isCharging: batteryLevel > 0.95, // Simple charging detection
      };

      setSystemData(newSystemData);
      
      // Notify parent component
      if (onSystemUpdate) {
        onSystemUpdate(newSystemData);
      }
    } catch (error) {
      console.log('Error loading system info:', error);
    }
  };

  const getStatusColor = (value, type) => {
    switch (type) {
      case 'ram':
        if (value > 80) return '#FF4444';
        if (value > 60) return '#FFA500';
        return '#4A90FB';
      case 'battery':
        if (value < 20) return '#FF4444';
        if (value < 50) return '#FFA500';
        return '#4A90FB';
      case 'temp':
        if (value > 70) return '#FF4444';
        if (value > 55) return '#FFA500';
        return '#4A90FB';
      case 'storage':
        if (value > 85) return '#FF4444';
        if (value > 70) return '#FFA500';
        return '#4A90FB';
      default:
        return '#4A90FB';
    }
  };

  const getPerformanceStatus = () => {
    const issues = [];
    if (systemData.ramUsage > 80) issues.push('RAM tinggi');
    if (systemData.cpuTemp > 70) issues.push('CPU panas');
    if (systemData.batteryLevel < 20) issues.push('Baterai rendah');
    if (systemData.storageUsed / systemData.storageTotal > 0.9) issues.push('Storage penuh');
    
    if (issues.length === 0) return { status: 'Optimal', color: '#4A90FB' };
    if (issues.length === 1) return { status: 'Perlu perhatian', color: '#FFA500' };
    return { status: 'Perlu optimasi', color: '#FF4444' };
  };

  const performanceStatus = getPerformanceStatus();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Device Information Header */}
      <View style={styles.deviceHeader}>
        <Text style={styles.deviceName}>{systemData.deviceName}</Text>
        <Text style={styles.systemVersion}>
          {Platform.OS === 'ios' ? 'iOS' : 'Android'} {systemData.systemVersion}
        </Text>
        <View style={[styles.statusBadge, { backgroundColor: performanceStatus.color }]}>
          <Text style={styles.statusText}>{performanceStatus.status}</Text>
        </View>
      </View>

      {/* Performance Metrics Grid */}
      <View style={styles.metricsGrid}>
        {/* RAM Usage */}
        <View style={[styles.metricCard, styles.largeCard]}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Penggunaan RAM</Text>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor(systemData.ramUsage, 'ram') }]} />
          </View>
          <Text style={styles.metricValue}>{systemData.ramUsageGB} GB</Text>
          <Text style={styles.metricSubtext}>dari {systemData.ramTotal} GB ({systemData.ramUsage}%)</Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { 
                  width: `${systemData.ramUsage}%`,
                  backgroundColor: getStatusColor(systemData.ramUsage, 'ram')
                }
              ]} 
            />
          </View>
        </View>

        {/* CPU Temperature */}
        <View style={styles.metricCard}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Suhu CPU</Text>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor(systemData.cpuTemp, 'temp') }]} />
          </View>
          <Text style={styles.metricValue}>{systemData.cpuTemp}°C</Text>
          <Text style={styles.metricSubtext}>
            {systemData.cpuTemp > 70 ? 'Panas' : systemData.cpuTemp > 55 ? 'Hangat' : 'Normal'}
          </Text>
        </View>

        {/* Battery Level */}
        <View style={styles.metricCard}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Baterai</Text>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor(systemData.batteryLevel, 'battery') }]} />
          </View>
          <Text style={styles.metricValue}>{systemData.batteryLevel}%</Text>
          <Text style={styles.metricSubtext}>
            {systemData.isCharging ? 'Mengisi daya' : 'Tidak mengisi'}
          </Text>
        </View>

        {/* Storage Usage */}
        <View style={[styles.metricCard, styles.largeCard]}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Penyimpanan</Text>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor((systemData.storageUsed / systemData.storageTotal) * 100, 'storage') }]} />
          </View>
          <Text style={styles.metricValue}>{systemData.storageUsed} GB</Text>
          <Text style={styles.metricSubtext}>dari {systemData.storageTotal} GB digunakan</Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { 
                  width: `${(systemData.storageUsed / systemData.storageTotal) * 100}%`,
                  backgroundColor: getStatusColor((systemData.storageUsed / systemData.storageTotal) * 100, 'storage')
                }
              ]} 
            />
          </View>
        </View>

        {/* Network Status */}
        <View style={styles.metricCard}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Jaringan</Text>
            <View style={[styles.statusDot, { backgroundColor: '#4A90FB' }]} />
          </View>
          <Text style={styles.metricValue}>{systemData.networkType}</Text>
          <Text style={styles.metricSubtext}>Terhubung</Text>
        </View>

        {/* Game Booster Status */}
        <View style={styles.metricCard}>
          <View style={styles.metricHeader}>
            <Text style={styles.metricTitle}>Game Booster</Text>
            <View style={[styles.statusDot, { backgroundColor: '#4A90FB' }]} />
          </View>
          <Text style={styles.metricValue}>ON</Text>
          <Text style={styles.metricSubtext}>Siap optimasi</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141820',
    paddingHorizontal: 16,
  },
  deviceHeader: {
    backgroundColor: '#1B2028',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#2D333A',
    alignItems: 'center',
  },
  deviceName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F0F6FC',
    marginBottom: 4,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  systemVersion: {
    fontSize: 14,
    color: '#8B949E',
    marginBottom: 12,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  statusBadge: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  metricCard: {
    backgroundColor: '#1B2028',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#2D333A',
    width: (width - 48) / 2,
  },
  largeCard: {
    width: width - 32,
  },
  metricHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricTitle: {
    fontSize: 12,
    color: '#8B949E',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F0F6FC',
    marginBottom: 4,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  metricSubtext: {
    fontSize: 12,
    color: '#8B949E',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(74, 144, 251, 0.2)',
    borderRadius: 2,
    marginTop: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
});

export default SystemInfo;