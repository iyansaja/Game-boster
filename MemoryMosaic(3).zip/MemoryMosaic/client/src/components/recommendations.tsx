import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getPriorityColor, cn } from "@/lib/utils";
import { X } from "lucide-react";
import type { Recommendation } from "@shared/schema";

export function Recommendations() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: recommendations, isLoading } = useQuery<Recommendation[]>({
    queryKey: ["/api/recommendations"],
  });

  const completeRecommendationMutation = useMutation({
    mutationFn: async (recommendationId: number) => {
      return apiRequest("PATCH", `/api/recommendations/${recommendationId}/complete`);
    },
    onSuccess: () => {
      toast({
        title: "Recommendation Completed",
        description: "Recommendation has been marked as completed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
    onError: () => {
      toast({
        title: "Action Failed",
        description: "Failed to complete recommendation.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            Loading recommendations...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!recommendations || recommendations.length === 0) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            No recommendations available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card neon-border">
      <CardHeader>
        <CardTitle>Recommendations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.map((recommendation) => (
            <div 
              key={recommendation.id}
              className={cn(
                "p-3 bg-muted rounded-lg border-l-4 relative group",
                getPriorityColor(recommendation.priority)
              )}
            >
              <div className="pr-8">
                <p className="font-medium mb-1">{recommendation.title}</p>
                <p className="text-muted-foreground text-xs">{recommendation.description}</p>
              </div>
              <Button
                onClick={() => completeRecommendationMutation.mutate(recommendation.id)}
                disabled={completeRecommendationMutation.isPending}
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
