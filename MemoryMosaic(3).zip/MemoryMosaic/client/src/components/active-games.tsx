import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { getStatusColor } from "@/lib/utils";
import { Settings } from "lucide-react";
import type { Game } from "@shared/schema";

export function ActiveGames() {
  const { data: games, isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  if (isLoading) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Active Games</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            Loading games...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!games || games.length === 0) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Active Games</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            No games detected
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card neon-border">
      <CardHeader>
        <CardTitle>Active Games</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {games.map((game) => (
            <div 
              key={game.id}
              className="flex items-center justify-between p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors"
            >
              <div className="flex items-center space-x-4">
                {game.iconUrl && (
                  <img 
                    src={game.iconUrl} 
                    alt={game.name} 
                    className="w-12 h-12 rounded-lg object-cover" 
                  />
                )}
                <div>
                  <p className="font-medium">{game.name}</p>
                  <p className={`text-sm capitalize ${getStatusColor(game.status)}`}>
                    {game.status === "running" ? "Running - Optimized" : 
                     game.status === "background" ? "Background Process" : 
                     "Idle"}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                {game.currentFps && (
                  <span className="text-green-400 text-sm font-medium">
                    {game.currentFps} FPS
                  </span>
                )}
                {!game.currentFps && game.status !== "running" && (
                  <span className="text-muted-foreground text-sm">Idle</span>
                )}
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="text-muted-foreground hover:text-blue-400"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
