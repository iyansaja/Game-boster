import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePerformanceHistory } from "@/hooks/use-performance-data";
import { Skeleton } from "@/components/ui/skeleton";

export function PerformanceChart() {
  const { data: history, isLoading } = usePerformanceHistory(50);

  if (isLoading) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Performance History</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!history || history.length === 0) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Performance History</CardTitle>
          <Select defaultValue="hour">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hour">Last Hour</SelectItem>
              <SelectItem value="day">Last Day</SelectItem>
              <SelectItem value="week">Last Week</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            No performance history available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card neon-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Performance History</CardTitle>
        <Select defaultValue="hour">
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hour">Last Hour</SelectItem>
            <SelectItem value="day">Last Day</SelectItem>
            <SelectItem value="week">Last Week</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="relative h-64 bg-muted rounded-lg p-4">
          {/* Chart grid lines */}
          <div className="absolute inset-4 grid grid-rows-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="border-b border-border opacity-30" />
            ))}
          </div>
          
          {/* Mock performance lines using SVG */}
          <svg className="absolute inset-4 w-full h-full" viewBox="0 0 400 200">
            {/* Generate CPU line from actual data */}
            <path 
              d={generatePath(history.map(h => h.cpuUsage), 400, 200, 100)} 
              stroke="hsl(var(--neon-green))" 
              strokeWidth="2" 
              fill="none"
              className="drop-shadow-lg"
            />
            {/* Generate RAM line from actual data */}
            <path 
              d={generatePath(history.map(h => (h.ramUsage / h.ramTotal) * 100), 400, 200, 100)} 
              stroke="hsl(var(--neon-blue))" 
              strokeWidth="2" 
              fill="none"
              className="drop-shadow-lg"
            />
            {/* Generate FPS line from actual data */}
            <path 
              d={generatePath(history.map(h => (h.fps / 200) * 100), 400, 200, 100)} 
              stroke="hsl(var(--neon-purple))" 
              strokeWidth="2" 
              fill="none"
              className="drop-shadow-lg"
            />
          </svg>
          
          {/* Legend */}
          <div className="absolute bottom-4 left-4 flex space-x-4 text-xs">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full" />
              <span className="text-muted-foreground">CPU</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-blue-400 rounded-full" />
              <span className="text-muted-foreground">RAM</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-purple-400 rounded-full" />
              <span className="text-muted-foreground">FPS</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function generatePath(data: number[], width: number, height: number, maxValue: number): string {
  if (data.length === 0) return "";
  
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * width;
    const y = height - ((value / maxValue) * height);
    return `${x},${y}`;
  });
  
  return `M ${points.join(" L ")}`;
}
