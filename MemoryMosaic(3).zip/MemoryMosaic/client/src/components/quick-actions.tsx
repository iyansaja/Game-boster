import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Rocket, Fan } from "lucide-react";

export function QuickActions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const optimizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/system/optimize");
    },
    onSuccess: () => {
      toast({
        title: "System Optimized",
        description: "Performance boost applied successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/system/settings"] });
    },
    onError: () => {
      toast({
        title: "Optimization Failed",
        description: "Failed to optimize system performance.",
        variant: "destructive",
      });
    },
  });

  const cleanupMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/system/cleanup");
    },
    onSuccess: (response) => {
      const data = response.json();
      toast({
        title: "Cleanup Complete",
        description: `System cleaned successfully! Freed up space.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/system/settings"] });
    },
    onError: () => {
      toast({
        title: "Cleanup Failed",
        description: "Failed to clean up system.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="metric-card neon-border">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button
            onClick={() => optimizeMutation.mutate()}
            disabled={optimizeMutation.isPending}
            className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-400 hover:to-blue-400 p-4 h-auto group"
          >
            <div className="flex items-center space-x-3">
              <Rocket className="text-white text-xl group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-white font-semibold">
                  {optimizeMutation.isPending ? "Optimizing..." : "Boost Performance"}
                </p>
                <p className="text-white text-xs opacity-80">One-click optimization</p>
              </div>
            </div>
          </Button>
          
          <Button
            onClick={() => cleanupMutation.mutate()}
            disabled={cleanupMutation.isPending}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-400 hover:to-blue-400 p-4 h-auto group"
          >
            <div className="flex items-center space-x-3">
              <Fan className="text-white text-xl group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-white font-semibold">
                  {cleanupMutation.isPending ? "Cleaning..." : "System Cleanup"}
                </p>
                <p className="text-white text-xs opacity-80">Free up space</p>
              </div>
            </div>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
