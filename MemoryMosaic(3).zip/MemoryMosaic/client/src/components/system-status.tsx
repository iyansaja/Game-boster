import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { formatTimeAgo } from "@/lib/utils";
import type { SystemSettings } from "@shared/schema";

export function SystemStatus() {
  const { data: settings, isLoading } = useQuery<SystemSettings>({
    queryKey: ["/api/system/settings"],
  });

  if (isLoading) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>System Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            Loading status...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!settings) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>System Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            Unable to load system status
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card neon-border">
      <CardHeader>
        <CardTitle>System Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground text-sm">Overall Health</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full pulse-glow" />
              <span className="text-green-400 text-sm font-medium">Excellent</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground text-sm">Game Ready</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full pulse-glow" />
              <span className="text-green-400 text-sm font-medium">
                {settings.gamingModeEnabled ? "Yes" : "No"}
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground text-sm">Storage Space</span>
            <span className="text-sm font-medium">847GB Free</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground text-sm">Last Optimized</span>
            <span className="text-sm font-medium">
              {settings.lastOptimized ? formatTimeAgo(new Date(settings.lastOptimized)) : "Never"}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
