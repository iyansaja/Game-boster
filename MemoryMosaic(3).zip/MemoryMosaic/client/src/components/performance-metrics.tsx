import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useLatestPerformanceMetrics } from "@/hooks/use-performance-data";
import { formatPercentage, formatTemperature, cn } from "@/lib/utils";
import { Cpu, MemoryStick, Gauge, Thermometer } from "lucide-react";

export function PerformanceMetrics() {
  const { data: metrics, isLoading } = useLatestPerformanceMetrics();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="metric-card neon-border">
            <CardContent className="p-6">
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="metric-card neon-border">
          <CardContent className="p-6">
            <div className="text-center text-muted-foreground">
              No performance data available
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* CPU Usage Card */}
      <Card className="metric-card neon-border hover:neon-blue-shadow transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                <Cpu className="text-white text-lg" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">CPU Usage</h3>
                <p className="text-2xl font-bold">{formatPercentage(metrics.cpuUsage)}</p>
              </div>
            </div>
          </div>
          <div className="relative h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="absolute top-0 left-0 h-full progress-bar rounded-full transition-all duration-300" 
              style={{ width: `${metrics.cpuUsage}%` }}
            />
          </div>
          <p className={cn(
            "text-xs mt-2",
            metrics.cpuUsage < 70 ? "text-green-400" : metrics.cpuUsage < 85 ? "text-yellow-400" : "text-red-400"
          )}>
            {metrics.cpuUsage < 70 ? "Optimal" : metrics.cpuUsage < 85 ? "High" : "Critical"}
          </p>
        </CardContent>
      </Card>

      {/* RAM Usage Card */}
      <Card className="metric-card neon-border hover:neon-green-shadow transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                <MemoryStick className="text-white text-lg" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">RAM Usage</h3>
                <p className="text-2xl font-bold">{metrics.ramUsage.toFixed(1)}GB</p>
              </div>
            </div>
          </div>
          <div className="relative h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-green-400 to-blue-400 rounded-full transition-all duration-300" 
              style={{ width: `${(metrics.ramUsage / metrics.ramTotal) * 100}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">of {metrics.ramTotal}GB</p>
        </CardContent>
      </Card>

      {/* FPS Counter */}
      <Card className="metric-card neon-border hover:neon-purple-shadow transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-green-500 rounded-lg flex items-center justify-center">
                <Gauge className="text-white text-lg" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Current FPS</h3>
                <p className="text-2xl font-bold">{metrics.fps}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full pulse-glow" />
            <p className={cn(
              "text-xs",
              metrics.fps >= 120 ? "text-green-400" : metrics.fps >= 60 ? "text-yellow-400" : "text-red-400"
            )}>
              {metrics.fps >= 120 ? "Ultra High" : metrics.fps >= 60 ? "High" : "Low"}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Temperature */}
      <Card className="metric-card neon-border hover:neon-blue-shadow transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center",
                metrics.gpuTemp < 70 ? "bg-gradient-to-r from-green-500 to-blue-500" :
                metrics.gpuTemp < 80 ? "bg-gradient-to-r from-yellow-500 to-orange-500" :
                "bg-gradient-to-r from-red-500 to-red-600"
              )}>
                <Thermometer className="text-white text-lg" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">GPU Temp</h3>
                <p className="text-2xl font-bold">{formatTemperature(metrics.gpuTemp)}</p>
              </div>
            </div>
          </div>
          <p className={cn(
            "text-xs",
            metrics.gpuTemp < 70 ? "text-green-400" : metrics.gpuTemp < 80 ? "text-yellow-400" : "text-red-400"
          )}>
            {metrics.gpuTemp < 70 ? "Normal Range" : metrics.gpuTemp < 80 ? "Warm" : "Hot"}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
