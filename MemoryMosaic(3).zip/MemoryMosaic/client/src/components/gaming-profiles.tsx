import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Check, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { GamingProfile } from "@shared/schema";

export function GamingProfiles() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: profiles, isLoading } = useQuery<GamingProfile[]>({
    queryKey: ["/api/profiles"],
  });

  const activateProfileMutation = useMutation({
    mutationFn: async (profileId: number) => {
      return apiRequest("POST", `/api/profiles/${profileId}/activate`);
    },
    onSuccess: () => {
      toast({
        title: "Profile Activated",
        description: "Gaming profile has been applied successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
    },
    onError: () => {
      toast({
        title: "Activation Failed",
        description: "Failed to activate gaming profile.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Gaming Profiles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            Loading profiles...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!profiles || profiles.length === 0) {
    return (
      <Card className="metric-card neon-border">
        <CardHeader>
          <CardTitle>Gaming Profiles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-4">
            No gaming profiles available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card neon-border">
      <CardHeader>
        <CardTitle>Gaming Profiles</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {profiles.map((profile) => (
            <Button
              key={profile.id}
              onClick={() => activateProfileMutation.mutate(profile.id)}
              disabled={activateProfileMutation.isPending}
              variant="ghost"
              className={cn(
                "w-full justify-between p-3 h-auto",
                profile.isActive 
                  ? "bg-gradient-to-r from-green-500 to-blue-500 text-white hover:from-green-400 hover:to-blue-400" 
                  : "bg-muted hover:bg-muted/80"
              )}
            >
              <span className="font-medium">{profile.name}</span>
              {profile.isActive && <Check className="h-4 w-4" />}
            </Button>
          ))}
          
          <Button 
            variant="ghost"
            className="w-full justify-start p-3 bg-muted hover:bg-muted/80 text-blue-400"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Custom
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
