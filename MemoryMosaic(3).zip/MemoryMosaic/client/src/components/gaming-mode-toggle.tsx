import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import type { SystemSettings } from "@shared/schema";

export function GamingModeToggle() {
  const queryClient = useQueryClient();
  
  const { data: settings } = useQuery<SystemSettings>({
    queryKey: ["/api/system/settings"],
  });

  const toggleMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      return apiRequest("PATCH", "/api/system/settings", {
        gamingModeEnabled: enabled,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/system/settings"] });
    },
  });

  const handleToggle = () => {
    if (settings) {
      toggleMutation.mutate(!settings.gamingModeEnabled);
    }
  };

  const isEnabled = settings?.gamingModeEnabled ?? false;

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm text-muted-foreground">Gaming Mode</span>
      <button 
        onClick={handleToggle}
        disabled={toggleMutation.isPending}
        className={cn(
          "relative w-12 h-6 rounded-full border transition-all duration-300",
          isEnabled 
            ? "bg-muted border-green-400 pulse-glow" 
            : "bg-muted border-border"
        )}
      >
        <div 
          className={cn(
            "absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300",
            isEnabled 
              ? "right-0.5 bg-green-400" 
              : "left-0.5 bg-muted-foreground"
          )}
        />
      </button>
    </div>
  );
}
