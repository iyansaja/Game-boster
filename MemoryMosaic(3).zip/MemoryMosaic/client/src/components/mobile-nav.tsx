import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Home, Gamepad2, Rocket, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { icon: Home, label: "Dashboard", path: "/" },
    { icon: Gamepad2, label: "Games", path: "/games" },
    { icon: Rocket, label: "Optimize", path: "/optimize" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 md:hidden z-50">
      <div className="flex items-center justify-around">
        {navItems.map(({ icon: Icon, label, path }) => (
          <Button
            key={path}
            variant="ghost"
            onClick={() => setLocation(path)}
            className={cn(
              "flex flex-col items-center space-y-1 h-auto py-2",
              location === path ? "text-green-400" : "text-muted-foreground"
            )}
          >
            <Icon className="h-5 w-5" />
            <span className="text-xs">{label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}
