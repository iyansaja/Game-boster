import { PerformanceMetrics } from "@/components/performance-metrics";
import { PerformanceChart } from "@/components/performance-chart";
import { GamingModeToggle } from "@/components/gaming-mode-toggle";
import { QuickActions } from "@/components/quick-actions";
import { ActiveGames } from "@/components/active-games";
import { SystemStatus } from "@/components/system-status";
import { GamingProfiles } from "@/components/gaming-profiles";
import { Recommendations } from "@/components/recommendations";
import { MobileNav } from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Menu, Zap } from "lucide-react";

export default function Dashboard() {
  return (
    <div className="min-h-screen">
      {/* Navigation Header */}
      <header className="bg-card border-b border-border px-4 py-3 sticky top-0 z-40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center blue-glow">
              <Zap className="text-white text-sm" />
            </div>
            <h1 className="text-xl font-bold text-primary">
              GameBoost Pro
            </h1>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#" className="text-muted-foreground hover:text-green-400 transition-colors">Dashboard</a>
            <a href="#" className="text-muted-foreground hover:text-green-400 transition-colors">Games</a>
            <a href="#" className="text-muted-foreground hover:text-green-400 transition-colors">Settings</a>
          </nav>
          
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm" className="md:hidden text-muted-foreground hover:text-green-400">
              <Menu className="h-4 w-4" />
            </Button>
            <GamingModeToggle />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 pb-20 md:pb-6">
        {/* Performance Overview Cards */}
        <div className="mb-8">
          <PerformanceMetrics />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Performance Dashboard */}
          <div className="lg:col-span-2 space-y-6">
            <QuickActions />
            <PerformanceChart />
            <ActiveGames />
          </div>

          {/* Sidebar Controls */}
          <div className="space-y-6">
            <SystemStatus />
            <GamingProfiles />
            <Recommendations />
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav />
    </div>
  );
}
