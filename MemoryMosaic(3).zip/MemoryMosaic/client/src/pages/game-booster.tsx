import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Zap, Plus } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import type { Game, SystemSettings } from "@shared/schema";

export default function GameBooster() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: games } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  const { data: settings } = useQuery<SystemSettings>({
    queryKey: ["/api/system/settings"],
  });

  const optimizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/system/optimize");
    },
    onSuccess: () => {
      toast({
        title: "Optimasi Berhasil",
        description: "Sistem telah dioptimalkan untuk performa gaming!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/system/settings"] });
    },
  });

  const gameApps = [
    {
      id: 1,
      name: "PUBG Mobile",
      icon: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      subtitle: "Tampilkan FPS",
      enabled: true
    },
    {
      id: 2,
      name: "Asphalt 9 Legends",
      icon: "https://images.unsplash.com/photo-1556438064-2d7646166914?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      subtitle: "Tampilkan FPS",
      enabled: true
    },
    {
      id: 3,
      name: "Call of Duty",
      icon: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      subtitle: "Tampilkan FPS",
      enabled: true
    },
    {
      id: 4,
      name: "Clash Royale",
      icon: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      subtitle: "Tampilkan FPS",
      enabled: true
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Game Booster</h1>
        </div>
        <Button 
          variant="ghost" 
          className="text-primary font-medium text-sm"
          onClick={() => optimizeMutation.mutate()}
          disabled={optimizeMutation.isPending}
        >
          {optimizeMutation.isPending ? "MENGOPTIMASI..." : "OPTIMASI"}
        </Button>
      </header>

      <div className="p-4 space-y-6">
        {/* Game Apps Grid */}
        <div className="grid grid-cols-2 gap-4">
          {gameApps.map((app) => (
            <Card key={app.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex flex-col items-center space-y-3">
                  <div className="w-16 h-16 rounded-xl overflow-hidden">
                    <img 
                      src={app.icon} 
                      alt={app.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-center">
                    <h3 className="font-medium text-foreground text-sm">{app.name}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{app.subtitle}</p>
                  </div>
                  <div className={cn(
                    "w-3 h-3 rounded-full",
                    app.enabled ? "bg-primary" : "bg-muted-foreground"
                  )} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add Games Button */}
        <Card className="bg-card border-border border-dashed">
          <CardContent className="p-4">
            <Button 
              variant="ghost" 
              className="w-full h-16 text-primary hover:text-primary/80"
            >
              <Plus className="h-6 w-6" />
            </Button>
          </CardContent>
        </Card>

        {/* Optimization Circle */}
        <div className="flex justify-center py-8">
          <div className="relative">
            <div className="w-48 h-48 rounded-full border-4 border-primary/20 flex items-center justify-center">
              <div className="w-40 h-40 rounded-full border-2 border-primary flex flex-col items-center justify-center bg-primary/5">
                <span className="text-primary font-bold text-lg">OPTIMASI</span>
                <span className="text-primary font-bold text-lg">SEKARANG</span>
              </div>
            </div>
            {/* Animated border */}
            <div className="absolute inset-0 w-48 h-48 rounded-full border-4 border-transparent border-t-primary animate-spin" 
                 style={{ animationDuration: '3s' }} />
          </div>
        </div>

        {/* System Info */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-xs text-muted-foreground">RAM</p>
            <p className="text-foreground font-semibold">3,8 GB</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Suhu</p>
            <p className="text-foreground font-semibold">44°C</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Status</p>
            <p className="text-foreground font-semibold">baterai</p>
          </div>
        </div>

        {/* Bottom Status */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-foreground">Game Booster</h3>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                  <span className="flex items-center space-x-1">
                    <div className="w-1 h-1 bg-primary rounded-full" />
                    <span>48°C Suhu CPU</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-1 h-1 bg-primary rounded-full" />
                    <span>2,3 GB / 4 GB RAM</span>
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}