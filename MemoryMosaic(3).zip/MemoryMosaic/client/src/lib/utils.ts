import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export function formatPercentage(value: number): string {
  return `${Math.round(value)}%`;
}

export function formatTemperature(temp: number): string {
  return `${Math.round(temp)}°C`;
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
  
  if (diffInMinutes < 1) return "Just now";
  if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `${diffInHours} hours ago`;
  
  const diffInDays = Math.floor(diffInHours / 24);
  return `${diffInDays} days ago`;
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "running":
      return "text-green-400";
    case "background":
      return "text-blue-400";
    case "idle":
      return "text-gray-400";
    default:
      return "text-gray-400";
  }
}

export function getPriorityColor(priority: string): string {
  switch (priority) {
    case "high":
      return "border-green-400";
    case "medium":
      return "border-blue-400";
    case "low":
      return "border-yellow-400";
    default:
      return "border-gray-400";
  }
}
