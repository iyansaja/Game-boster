import { useQuery } from "@tanstack/react-query";
import type { PerformanceMetrics } from "@shared/schema";

export function useLatestPerformanceMetrics() {
  return useQuery<PerformanceMetrics>({
    queryKey: ["/api/performance/latest"],
    refetchInterval: 2000, // Update every 2 seconds
  });
}

export function usePerformanceHistory(limit: number = 50) {
  return useQuery<PerformanceMetrics[]>({
    queryKey: ["/api/performance/history", limit],
    refetchInterval: 5000, // Update every 5 seconds
  });
}
