/**
 * GameList.js - Cross-Platform Game List Component
 * Compatible with Android & iOS React Native
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Platform,
  Dimensions,
  Switch,
  Alert,
} from 'react-native';

const { width } = Dimensions.get('window');

const GameList = ({ onGameToggle, onGameOptimize }) => {
  const [games, setGames] = useState([
    {
      id: 1,
      name: 'PUBG Mobile',
      packageName: 'com.tencent.ig',
      icon: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: true,
      isRunning: true,
      fps: 60,
      ramUsage: 2.1,
      priority: 'high',
      status: 'Dioptimasi',
    },
    {
      id: 2,
      name: 'Asphalt 9 Legends',
      packageName: 'com.gameloft.android.ANMP.GloftA9HM',
      icon: 'https://images.unsplash.com/photo-1556438064-2d7646166914?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: true,
      isRunning: false,
      fps: 0,
      ramUsage: 0.8,
      priority: 'medium',
      status: 'Siap',
    },
    {
      id: 3,
      name: 'Call of Duty Mobile',
      packageName: 'com.activision.callofduty.shooter',
      icon: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: true,
      isRunning: false,
      fps: 0,
      ramUsage: 0.5,
      priority: 'high',
      status: 'Siap',
    },
    {
      id: 4,
      name: 'Clash Royale',
      packageName: 'com.supercell.clashroyale',
      icon: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: false,
      isRunning: false,
      fps: 0,
      ramUsage: 0.3,
      priority: 'low',
      status: 'Nonaktif',
    },
    {
      id: 5,
      name: 'Mobile Legends',
      packageName: 'com.mobile.legends',
      icon: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: true,
      isRunning: false,
      fps: 0,
      ramUsage: 0.6,
      priority: 'medium',
      status: 'Siap',
    },
    {
      id: 6,
      name: 'Free Fire',
      packageName: 'com.dts.freefireth',
      icon: 'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80',
      isEnabled: true,
      isRunning: false,
      fps: 0,
      ramUsage: 0.4,
      priority: 'medium',
      status: 'Siap',
    },
  ]);

  const toggleGameBoost = (gameId) => {
    setGames(prevGames =>
      prevGames.map(game =>
        game.id === gameId
          ? {
              ...game,
              isEnabled: !game.isEnabled,
              status: !game.isEnabled ? 'Siap' : 'Nonaktif',
            }
          : game
      )
    );

    const game = games.find(g => g.id === gameId);
    if (onGameToggle) {
      onGameToggle(game, !game.isEnabled);
    }
  };

  const optimizeGame = (game) => {
    Alert.alert(
      'Optimasi Game',
      `Optimasi ${game.name}?\n\nTindakan yang akan dilakukan:\n• Tingkatkan prioritas CPU\n• Bersihkan RAM\n• Matikan aplikasi latar belakang\n• Optimalkan jaringan`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Optimasi',
          onPress: () => {
            setGames(prevGames =>
              prevGames.map(g =>
                g.id === game.id
                  ? { ...g, status: 'Dioptimasi', fps: Math.max(60, g.fps) }
                  : g
              )
            );

            if (onGameOptimize) {
              onGameOptimize(game);
            }
          },
        },
      ]
    );
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Dioptimasi':
        return '#4A90FB';
      case 'Siap':
        return '#00C853';
      case 'Nonaktif':
        return '#8B949E';
      default:
        return '#8B949E';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return '#FF4444';
      case 'medium':
        return '#FFA500';
      case 'low':
        return '#4A90FB';
      default:
        return '#8B949E';
    }
  };

  const renderGameItem = ({ item }) => (
    <View style={styles.gameCard}>
      <View style={styles.gameHeader}>
        <View style={styles.gameInfo}>
          <Image source={{ uri: item.icon }} style={styles.gameIcon} />
          <View style={styles.gameDetails}>
            <Text style={styles.gameName}>{item.name}</Text>
            <View style={styles.gameStats}>
              {item.isRunning && (
                <Text style={styles.fpsText}>{item.fps} FPS</Text>
              )}
              <Text style={styles.ramText}>{item.ramUsage} GB</Text>
              <View
                style={[
                  styles.priorityBadge,
                  { backgroundColor: getPriorityColor(item.priority) },
                ]}
              >
                <Text style={styles.priorityText}>
                  {item.priority.toUpperCase()}
                </Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.gameControls}>
          <Switch
            value={item.isEnabled}
            onValueChange={() => toggleGameBoost(item.id)}
            trackColor={{
              false: '#2D333A',
              true: 'rgba(74, 144, 251, 0.3)',
            }}
            thumbColor={item.isEnabled ? '#4A90FB' : '#8B949E'}
            ios_backgroundColor="#2D333A"
          />
        </View>
      </View>

      <View style={styles.gameFooter}>
        <View style={styles.statusContainer}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: getStatusColor(item.status) },
            ]}
          />
          <Text style={styles.statusText}>{item.status}</Text>
        </View>

        {item.isEnabled && (
          <TouchableOpacity
            style={styles.optimizeButton}
            onPress={() => optimizeGame(item)}
          >
            <Text style={styles.optimizeButtonText}>Optimasi</Text>
          </TouchableOpacity>
        )}
      </View>

      {item.isRunning && (
        <View style={styles.runningIndicator}>
          <View style={styles.pulsingDot} />
          <Text style={styles.runningText}>Sedang berjalan</Text>
        </View>
      )}
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>Game yang Terdeteksi</Text>
      <Text style={styles.headerSubtitle}>
        {games.filter(g => g.isEnabled).length} dari {games.length} game aktif
      </Text>
    </View>
  );

  const renderFooter = () => (
    <View style={styles.footer}>
      <TouchableOpacity style={styles.addGameButton}>
        <Text style={styles.addGameText}>+ Tambah Game Manual</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={games}
        renderItem={renderGameItem}
        keyExtractor={item => item.id.toString()}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141820',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  header: {
    marginBottom: 20,
    paddingTop: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F0F6FC',
    marginBottom: 4,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#8B949E',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  gameCard: {
    backgroundColor: '#1B2028',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2D333A',
    position: 'relative',
  },
  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  gameInfo: {
    flexDirection: 'row',
    flex: 1,
  },
  gameIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    marginRight: 12,
  },
  gameDetails: {
    flex: 1,
  },
  gameName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F0F6FC',
    marginBottom: 6,
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  gameStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  fpsText: {
    fontSize: 12,
    color: '#4A90FB',
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  ramText: {
    fontSize: 12,
    color: '#8B949E',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  priorityBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  priorityText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  gameControls: {
    alignItems: 'center',
  },
  gameFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    fontSize: 12,
    color: '#8B949E',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  optimizeButton: {
    backgroundColor: '#4A90FB',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  optimizeButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  runningIndicator: {
    position: 'absolute',
    top: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(74, 144, 251, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  pulsingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#4A90FB',
    marginRight: 4,
  },
  runningText: {
    fontSize: 10,
    color: '#4A90FB',
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
  footer: {
    marginTop: 20,
    alignItems: 'center',
  },
  addGameButton: {
    backgroundColor: 'rgba(74, 144, 251, 0.1)',
    borderWidth: 2,
    borderColor: '#4A90FB',
    borderStyle: 'dashed',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  addGameText: {
    color: '#4A90FB',
    fontSize: 14,
    fontWeight: 'bold',
    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
  },
});

export default GameList;