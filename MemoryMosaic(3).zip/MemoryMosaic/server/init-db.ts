import { db } from "./db";
import { games, gamingProfiles, recommendations, systemSettings } from "@shared/schema";

export async function initializeDatabase() {
  try {
    // Check if data already exists
    const existingGames = await db.select().from(games).limit(1);
    if (existingGames.length > 0) {
      console.log("Database already initialized");
      return;
    }

    // Insert default games
    await db.insert(games).values([
      {
        name: "PUBG Mobile",
        processName: "PUBG.exe",
        isActive: true,
        currentFps: 144,
        status: "running",
        iconUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      },
      {
        name: "Asphalt 9 Legends",
        processName: "Asphalt9.exe",
        isActive: false,
        currentFps: null,
        status: "background",
        iconUrl: "https://images.unsplash.com/photo-1556438064-2d7646166914?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      },
      {
        name: "Call of Duty",
        processName: "COD.exe",
        isActive: false,
        currentFps: null,
        status: "idle",
        iconUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      },
      {
        name: "Clash Royale",
        processName: "ClashRoyale.exe",
        isActive: false,
        currentFps: null,
        status: "idle",
        iconUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      }
    ]);

    // Insert default gaming profiles
    await db.insert(gamingProfiles).values([
      {
        name: "Ultra Performance",
        isActive: true,
        cpuPriority: "high",
        ramOptimization: true,
        backgroundAppsDisabled: true,
      },
      {
        name: "Balanced",
        isActive: false,
        cpuPriority: "normal",
        ramOptimization: true,
        backgroundAppsDisabled: false,
      },
      {
        name: "Power Saver",
        isActive: false,
        cpuPriority: "low",
        ramOptimization: false,
        backgroundAppsDisabled: false,
      },
    ]);

    // Insert system settings
    await db.insert(systemSettings).values({
      gamingModeEnabled: true,
      lastOptimized: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      autoOptimization: false,
    });

    // Insert default recommendations
    await db.insert(recommendations).values([
      {
        title: "Close Background Apps",
        description: "Free up 2.1GB RAM by closing unused applications",
        type: "performance",
        priority: "high",
        isCompleted: false,
      },
      {
        title: "Update Graphics Driver",
        description: "New driver available for 15% performance boost",
        type: "update",
        priority: "medium",
        isCompleted: false,
      },
      {
        title: "Disk Cleanup",
        description: "Clean temporary files to free 8.4GB space",
        type: "cleanup",
        priority: "low",
        isCompleted: false,
      },
    ]);

    console.log("Database initialized with default data");
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}