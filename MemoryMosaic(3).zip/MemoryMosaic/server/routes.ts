import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertPerformanceMetricsSchema,
  insertGameSchema,
  insertGamingProfileSchema,
  insertSystemSettingsSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Performance metrics endpoints
  app.get("/api/performance/latest", async (req, res) => {
    try {
      const metrics = await storage.getLatestPerformanceMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch latest performance metrics" });
    }
  });

  app.get("/api/performance/history", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const history = await storage.getPerformanceHistory(limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch performance history" });
    }
  });

  app.post("/api/performance", async (req, res) => {
    try {
      const validatedData = insertPerformanceMetricsSchema.parse(req.body);
      const metrics = await storage.createPerformanceMetrics(validatedData);
      res.json(metrics);
    } catch (error) {
      res.status(400).json({ message: "Invalid performance metrics data" });
    }
  });

  // Games endpoints
  app.get("/api/games", async (req, res) => {
    try {
      const games = await storage.getAllGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch games" });
    }
  });

  app.get("/api/games/active", async (req, res) => {
    try {
      const activeGames = await storage.getActiveGames();
      res.json(activeGames);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active games" });
    }
  });

  app.post("/api/games", async (req, res) => {
    try {
      const validatedData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(validatedData);
      res.json(game);
    } catch (error) {
      res.status(400).json({ message: "Invalid game data" });
    }
  });

  app.patch("/api/games/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isActive, currentFps } = req.body;
      const updatedGame = await storage.updateGameStatus(id, isActive, currentFps);
      if (updatedGame) {
        res.json(updatedGame);
      } else {
        res.status(404).json({ message: "Game not found" });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to update game status" });
    }
  });

  // Gaming profiles endpoints
  app.get("/api/profiles", async (req, res) => {
    try {
      const profiles = await storage.getGamingProfiles();
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch gaming profiles" });
    }
  });

  app.get("/api/profiles/active", async (req, res) => {
    try {
      const activeProfile = await storage.getActiveGamingProfile();
      res.json(activeProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active profile" });
    }
  });

  app.post("/api/profiles", async (req, res) => {
    try {
      const validatedData = insertGamingProfileSchema.parse(req.body);
      const profile = await storage.createGamingProfile(validatedData);
      res.json(profile);
    } catch (error) {
      res.status(400).json({ message: "Invalid gaming profile data" });
    }
  });

  app.post("/api/profiles/:id/activate", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.setActiveProfile(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to activate profile" });
    }
  });

  // System settings endpoints
  app.get("/api/system/settings", async (req, res) => {
    try {
      const settings = await storage.getSystemSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system settings" });
    }
  });

  app.patch("/api/system/settings", async (req, res) => {
    try {
      const validatedData = insertSystemSettingsSchema.partial().parse(req.body);
      const settings = await storage.updateSystemSettings(validatedData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Invalid system settings data" });
    }
  });

  // Optimization endpoints
  app.post("/api/system/optimize", async (req, res) => {
    try {
      const settings = await storage.updateSystemSettings({
        lastOptimized: new Date(),
      });
      res.json({ success: true, lastOptimized: settings.lastOptimized });
    } catch (error) {
      res.status(500).json({ message: "Failed to optimize system" });
    }
  });

  app.post("/api/system/cleanup", async (req, res) => {
    try {
      // Simulate cleanup process
      const settings = await storage.updateSystemSettings({
        lastOptimized: new Date(),
      });
      res.json({ success: true, freedSpace: "8.4GB", lastOptimized: settings.lastOptimized });
    } catch (error) {
      res.status(500).json({ message: "Failed to cleanup system" });
    }
  });

  // Recommendations endpoints
  app.get("/api/recommendations", async (req, res) => {
    try {
      const recommendations = await storage.getRecommendations();
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.patch("/api/recommendations/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markRecommendationCompleted(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to mark recommendation as completed" });
    }
  });

  // Simulate real-time performance data updates
  const broadcastPerformanceUpdate = () => {
    const cpuUsage = Math.floor(Math.random() * 20) + 40; // 40-60%
    const ramUsage = Math.floor(Math.random() * 4) + 12; // 12-16GB
    const fps = Math.floor(Math.random() * 20) + 135; // 135-155 FPS
    const gpuTemp = Math.floor(Math.random() * 15) + 60; // 60-75°C

    storage.createPerformanceMetrics({
      cpuUsage,
      ramUsage,
      ramTotal: 16,
      fps,
      gpuTemp,
    });
  };

  // Update performance metrics every 2 seconds
  setInterval(broadcastPerformanceUpdate, 2000);

  const httpServer = createServer(app);
  return httpServer;
}
