import {
  performanceMetrics,
  games,
  gamingProfiles,
  systemSettings,
  recommendations,
  type PerformanceMetrics,
  type InsertPerformanceMetrics,
  type Game,
  type InsertGame,
  type GamingProfile,
  type InsertGamingProfile,
  type SystemSettings,
  type InsertSystemSettings,
  type Recommendation,
  type InsertRecommendation,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Performance metrics
  getLatestPerformanceMetrics(): Promise<PerformanceMetrics | undefined>;
  getPerformanceHistory(limit?: number): Promise<PerformanceMetrics[]>;
  createPerformanceMetrics(metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics>;

  // Games
  getActiveGames(): Promise<Game[]>;
  getAllGames(): Promise<Game[]>;
  createGame(game: InsertGame): Promise<Game>;
  updateGameStatus(id: number, isActive: boolean, currentFps?: number): Promise<Game | undefined>;

  // Gaming profiles
  getGamingProfiles(): Promise<GamingProfile[]>;
  getActiveGamingProfile(): Promise<GamingProfile | undefined>;
  createGamingProfile(profile: InsertGamingProfile): Promise<GamingProfile>;
  setActiveProfile(id: number): Promise<void>;

  // System settings
  getSystemSettings(): Promise<SystemSettings>;
  updateSystemSettings(settings: Partial<InsertSystemSettings>): Promise<SystemSettings>;

  // Recommendations
  getRecommendations(): Promise<Recommendation[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  markRecommendationCompleted(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getLatestPerformanceMetrics(): Promise<PerformanceMetrics | undefined> {
    const [latest] = await db.select().from(performanceMetrics)
      .orderBy(performanceMetrics.timestamp)
      .limit(1);
    return latest || undefined;
  }

  async getPerformanceHistory(limit: number = 50): Promise<PerformanceMetrics[]> {
    return await db.select().from(performanceMetrics)
      .orderBy(performanceMetrics.timestamp)
      .limit(limit);
  }

  async createPerformanceMetrics(metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics> {
    const [newMetrics] = await db
      .insert(performanceMetrics)
      .values(metrics)
      .returning();
    return newMetrics;
  }

  async getActiveGames(): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.isActive, true));
  }

  async getAllGames(): Promise<Game[]> {
    return await db.select().from(games);
  }

  async createGame(game: InsertGame): Promise<Game> {
    const [newGame] = await db
      .insert(games)
      .values(game)
      .returning();
    return newGame;
  }

  async updateGameStatus(id: number, isActive: boolean, currentFps?: number): Promise<Game | undefined> {
    const [updatedGame] = await db
      .update(games)
      .set({ isActive, currentFps: currentFps ?? null })
      .where(eq(games.id, id))
      .returning();
    return updatedGame || undefined;
  }

  async getGamingProfiles(): Promise<GamingProfile[]> {
    return await db.select().from(gamingProfiles);
  }

  async getActiveGamingProfile(): Promise<GamingProfile | undefined> {
    const [activeProfile] = await db.select().from(gamingProfiles)
      .where(eq(gamingProfiles.isActive, true));
    return activeProfile || undefined;
  }

  async createGamingProfile(profile: InsertGamingProfile): Promise<GamingProfile> {
    const [newProfile] = await db
      .insert(gamingProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async setActiveProfile(id: number): Promise<void> {
    // Deactivate all profiles
    await db.update(gamingProfiles).set({ isActive: false });
    
    // Activate the selected profile
    await db.update(gamingProfiles)
      .set({ isActive: true })
      .where(eq(gamingProfiles.id, id));
  }

  async getSystemSettings(): Promise<SystemSettings> {
    const [settings] = await db.select().from(systemSettings).limit(1);
    if (!settings) {
      // Create default settings if none exist
      const [newSettings] = await db
        .insert(systemSettings)
        .values({
          gamingModeEnabled: true,
          lastOptimized: new Date(Date.now() - 2 * 60 * 60 * 1000),
          autoOptimization: false,
        })
        .returning();
      return newSettings;
    }
    return settings;
  }

  async updateSystemSettings(settings: Partial<InsertSystemSettings>): Promise<SystemSettings> {
    const existingSettings = await this.getSystemSettings();
    const [updatedSettings] = await db
      .update(systemSettings)
      .set(settings)
      .where(eq(systemSettings.id, existingSettings.id))
      .returning();
    return updatedSettings;
  }

  async getRecommendations(): Promise<Recommendation[]> {
    return await db.select().from(recommendations)
      .where(eq(recommendations.isCompleted, false));
  }

  async createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation> {
    const [newRecommendation] = await db
      .insert(recommendations)
      .values(recommendation)
      .returning();
    return newRecommendation;
  }

  async markRecommendationCompleted(id: number): Promise<void> {
    await db.update(recommendations)
      .set({ isCompleted: true })
      .where(eq(recommendations.id, id));
  }
}

export class MemStorage implements IStorage {
  private performanceMetricsData: Map<number, PerformanceMetrics>;
  private gamesData: Map<number, Game>;
  private gamingProfilesData: Map<number, GamingProfile>;
  private systemSettingsData: SystemSettings;
  private recommendationsData: Map<number, Recommendation>;
  private currentId: number;

  constructor() {
    this.performanceMetricsData = new Map();
    this.gamesData = new Map();
    this.gamingProfilesData = new Map();
    this.recommendationsData = new Map();
    this.currentId = 1;

    // Initialize with default data
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Default system settings
    this.systemSettingsData = {
      id: 1,
      gamingModeEnabled: true,
      lastOptimized: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      autoOptimization: false,
    };

    // Default gaming profiles
    const defaultProfiles: GamingProfile[] = [
      {
        id: 1,
        name: "Ultra Performance",
        isActive: true,
        cpuPriority: "high",
        ramOptimization: true,
        backgroundAppsDisabled: true,
      },
      {
        id: 2,
        name: "Balanced",
        isActive: false,
        cpuPriority: "normal",
        ramOptimization: true,
        backgroundAppsDisabled: false,
      },
      {
        id: 3,
        name: "Power Saver",
        isActive: false,
        cpuPriority: "low",
        ramOptimization: false,
        backgroundAppsDisabled: false,
      },
    ];

    defaultProfiles.forEach(profile => {
      this.gamingProfilesData.set(profile.id, profile);
    });

    // Default games
    const defaultGames: Game[] = [
      {
        id: 1,
        name: "Cyberpunk 2077",
        processName: "Cyberpunk2077.exe",
        isActive: true,
        currentFps: 144,
        status: "running",
        iconUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      },
      {
        id: 2,
        name: "Valorant",
        processName: "VALORANT.exe",
        isActive: false,
        currentFps: null,
        status: "background",
        iconUrl: "https://images.unsplash.com/photo-1556438064-2d7646166914?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      },
    ];

    defaultGames.forEach(game => {
      this.gamesData.set(game.id, game);
    });

    // Default recommendations
    const defaultRecommendations: Recommendation[] = [
      {
        id: 1,
        title: "Close Background Apps",
        description: "Free up 2.1GB RAM by closing unused applications",
        type: "performance",
        priority: "high",
        isCompleted: false,
      },
      {
        id: 2,
        title: "Update Graphics Driver",
        description: "New driver available for 15% performance boost",
        type: "update",
        priority: "medium",
        isCompleted: false,
      },
      {
        id: 3,
        title: "Disk Cleanup",
        description: "Clean temporary files to free 8.4GB space",
        type: "cleanup",
        priority: "low",
        isCompleted: false,
      },
    ];

    defaultRecommendations.forEach(rec => {
      this.recommendationsData.set(rec.id, rec);
    });

    this.currentId = 10;
  }

  async getLatestPerformanceMetrics(): Promise<PerformanceMetrics | undefined> {
    const metrics = Array.from(this.performanceMetricsData.values());
    return metrics[metrics.length - 1];
  }

  async getPerformanceHistory(limit: number = 50): Promise<PerformanceMetrics[]> {
    const metrics = Array.from(this.performanceMetricsData.values());
    return metrics.slice(-limit);
  }

  async createPerformanceMetrics(metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics> {
    const id = this.currentId++;
    const newMetrics: PerformanceMetrics = {
      ...metrics,
      id,
      timestamp: new Date(),
    };
    this.performanceMetricsData.set(id, newMetrics);
    return newMetrics;
  }

  async getActiveGames(): Promise<Game[]> {
    return Array.from(this.gamesData.values()).filter(game => game.isActive);
  }

  async getAllGames(): Promise<Game[]> {
    return Array.from(this.gamesData.values());
  }

  async createGame(game: InsertGame): Promise<Game> {
    const id = this.currentId++;
    const newGame: Game = { ...game, id };
    this.gamesData.set(id, newGame);
    return newGame;
  }

  async updateGameStatus(id: number, isActive: boolean, currentFps?: number): Promise<Game | undefined> {
    const game = this.gamesData.get(id);
    if (game) {
      const updatedGame = { ...game, isActive, currentFps };
      this.gamesData.set(id, updatedGame);
      return updatedGame;
    }
    return undefined;
  }

  async getGamingProfiles(): Promise<GamingProfile[]> {
    return Array.from(this.gamingProfilesData.values());
  }

  async getActiveGamingProfile(): Promise<GamingProfile | undefined> {
    return Array.from(this.gamingProfilesData.values()).find(profile => profile.isActive);
  }

  async createGamingProfile(profile: InsertGamingProfile): Promise<GamingProfile> {
    const id = this.currentId++;
    const newProfile: GamingProfile = { ...profile, id };
    this.gamingProfilesData.set(id, newProfile);
    return newProfile;
  }

  async setActiveProfile(id: number): Promise<void> {
    // Deactivate all profiles
    this.gamingProfilesData.forEach(profile => {
      profile.isActive = false;
    });
    
    // Activate the selected profile
    const profile = this.gamingProfilesData.get(id);
    if (profile) {
      profile.isActive = true;
    }
  }

  async getSystemSettings(): Promise<SystemSettings> {
    return this.systemSettingsData;
  }

  async updateSystemSettings(settings: Partial<InsertSystemSettings>): Promise<SystemSettings> {
    this.systemSettingsData = { ...this.systemSettingsData, ...settings };
    return this.systemSettingsData;
  }

  async getRecommendations(): Promise<Recommendation[]> {
    return Array.from(this.recommendationsData.values()).filter(rec => !rec.isCompleted);
  }

  async createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation> {
    const id = this.currentId++;
    const newRecommendation: Recommendation = { ...recommendation, id };
    this.recommendationsData.set(id, newRecommendation);
    return newRecommendation;
  }

  async markRecommendationCompleted(id: number): Promise<void> {
    const recommendation = this.recommendationsData.get(id);
    if (recommendation) {
      recommendation.isCompleted = true;
    }
  }
}

export const storage = new DatabaseStorage();
